
import React from "react";
import { FaMinus, FaPlus } from "react-icons/fa";

const CartAmountToggle=({amount, setIncrease, setDecrease})=>{
    return(
        <div className="cart-button">
            <div className="amount-toggle">

            <button onClick={()=>setDecrease()}>
                <FaMinus />
            </button>

            <div className="amount-style">{amount}</div>

            <button >
                <FaPlus onClick={()=>setIncrease()}/>
            </button>

            </div>
        </div>
    )
}

export default CartAmountToggle;